--
-- PostgreSQL database dump
--

\restrict SOimFHM7IDLgnVvVji51OQbZcbXbDi6U9QBUYCTKAbzVSPAV0fX9n5ujcKAARyl

-- Dumped from database version 16.6
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: appuser
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO appuser;

--
-- Name: enum_categorias_tipo; Type: TYPE; Schema: public; Owner: appuser
--

CREATE TYPE public.enum_categorias_tipo AS ENUM (
    'categoria1',
    'categoria2',
    'categoria3'
);


ALTER TYPE public.enum_categorias_tipo OWNER TO appuser;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Rols; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public."Rols" (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    descripcion character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Rols" OWNER TO appuser;

--
-- Name: Rols_id_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public."Rols_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Rols_id_seq" OWNER TO appuser;

--
-- Name: Rols_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public."Rols_id_seq" OWNED BY public."Rols".id;


--
-- Name: categorias; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.categorias (
    "idCategoria" integer NOT NULL,
    nombre character varying(100) NOT NULL,
    tipo public.enum_categorias_tipo NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.categorias OWNER TO appuser;

--
-- Name: categorias_idCategoria_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public."categorias_idCategoria_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."categorias_idCategoria_seq" OWNER TO appuser;

--
-- Name: categorias_idCategoria_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public."categorias_idCategoria_seq" OWNED BY public.categorias."idCategoria";


--
-- Name: clubs; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.clubs (
    "idClub" integer NOT NULL,
    nombre character varying(255) NOT NULL,
    direccion character varying(255) NOT NULL,
    telefono character varying(20),
    email character varying(255) NOT NULL,
    cuit character varying(15) NOT NULL,
    "fechaAfiliacion" date NOT NULL,
    "estadoAfiliacion" character varying(50) NOT NULL,
    logo character varying(1000),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.clubs OWNER TO appuser;

--
-- Name: COLUMN clubs.logo; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.clubs.logo IS 'URL del logo del club almacenado en ImgBB';


--
-- Name: clubs_idClub_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public."clubs_idClub_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."clubs_idClub_seq" OWNER TO appuser;

--
-- Name: clubs_idClub_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public."clubs_idClub_seq" OWNED BY public.clubs."idClub";


--
-- Name: cobros; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.cobros (
    "idCobro" integer NOT NULL,
    concepto character varying(255) NOT NULL,
    monto numeric(10,2) NOT NULL,
    "fechaCobro" date NOT NULL,
    "fechaVencimiento" date,
    estado character varying(50) DEFAULT 'Pendiente'::character varying NOT NULL,
    "comprobantePago" character varying(255),
    observaciones text,
    "preferenciaMP" character varying(255),
    "fechaPago" timestamp with time zone,
    "idClub" integer NOT NULL,
    "idEquipo" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.cobros OWNER TO appuser;

--
-- Name: COLUMN cobros."comprobantePago"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.cobros."comprobantePago" IS 'Número/código de comprobante de pago';


--
-- Name: COLUMN cobros."preferenciaMP"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.cobros."preferenciaMP" IS 'ID de preferencia de MercadoPago para pagos online';


--
-- Name: COLUMN cobros."fechaPago"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.cobros."fechaPago" IS 'Fecha en que se registró el pago';


--
-- Name: cobros_idCobro_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public."cobros_idCobro_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."cobros_idCobro_seq" OWNER TO appuser;

--
-- Name: cobros_idCobro_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public."cobros_idCobro_seq" OWNED BY public.cobros."idCobro";


--
-- Name: contactos; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.contactos (
    "idContacto" integer NOT NULL,
    direccion text,
    telefono character varying(100),
    email character varying(100),
    horarios text,
    "mapaEmbed" text,
    facebook character varying(255),
    instagram character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.contactos OWNER TO appuser;

--
-- Name: contactos_idContacto_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public."contactos_idContacto_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."contactos_idContacto_seq" OWNER TO appuser;

--
-- Name: contactos_idContacto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public."contactos_idContacto_seq" OWNED BY public.contactos."idContacto";


--
-- Name: credenciales; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.credenciales (
    "idCredencial" integer NOT NULL,
    identificador character varying(50) NOT NULL,
    "fechaAlta" date NOT NULL,
    "fechaVencimiento" date NOT NULL,
    estado character varying(20) DEFAULT 'ACTIVO'::character varying NOT NULL,
    "motivoSuspension" character varying(255),
    "idPersona" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.credenciales OWNER TO appuser;

--
-- Name: COLUMN credenciales.identificador; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.credenciales.identificador IS 'Código único de identificación para la credencial';


--
-- Name: COLUMN credenciales."fechaAlta"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.credenciales."fechaAlta" IS 'Fecha de emisión de la credencial (referencia a fechaLicencia de Persona)';


--
-- Name: COLUMN credenciales."fechaVencimiento"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.credenciales."fechaVencimiento" IS 'Fecha en la que vence la credencial (referencia a fechaLicenciaBaja de Persona)';


--
-- Name: COLUMN credenciales.estado; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.credenciales.estado IS 'Estado de la credencial: ACTIVO, INACTIVO, SUSPENDIDO, VENCIDO';


--
-- Name: COLUMN credenciales."motivoSuspension"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.credenciales."motivoSuspension" IS 'Motivo de suspensión si el estado es SUSPENDIDO';


--
-- Name: COLUMN credenciales."idPersona"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.credenciales."idPersona" IS 'ID de la persona a la que pertenece esta credencial';


--
-- Name: credenciales_idCredencial_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public."credenciales_idCredencial_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."credenciales_idCredencial_seq" OWNER TO appuser;

--
-- Name: credenciales_idCredencial_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public."credenciales_idCredencial_seq" OWNED BY public.credenciales."idCredencial";


--
-- Name: equipos; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.equipos (
    "idEquipo" integer NOT NULL,
    nombre character varying(255) NOT NULL,
    "idClub" integer,
    "idCategoria" integer,
    "nombreDelegado" character varying(255),
    "telefonoDelegado" character varying(20),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.equipos OWNER TO appuser;

--
-- Name: equipos_idEquipo_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public."equipos_idEquipo_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."equipos_idEquipo_seq" OWNER TO appuser;

--
-- Name: equipos_idEquipo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public."equipos_idEquipo_seq" OWNED BY public.equipos."idEquipo";


--
-- Name: hero_config; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.hero_config (
    id_config integer NOT NULL,
    eslogan character varying(100) DEFAULT 'Pasión por el Voleibol'::character varying NOT NULL,
    sub_texto text DEFAULT 'Promoviendo el voleibol en la provincia de Jujuy desde sus bases'::text NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    fecha_creacion timestamp with time zone NOT NULL,
    fecha_actualizacion timestamp with time zone NOT NULL
);


ALTER TABLE public.hero_config OWNER TO appuser;

--
-- Name: hero_config_id_config_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public.hero_config_id_config_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hero_config_id_config_seq OWNER TO appuser;

--
-- Name: hero_config_id_config_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public.hero_config_id_config_seq OWNED BY public.hero_config.id_config;


--
-- Name: hero_images; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.hero_images (
    id_imagen integer NOT NULL,
    id_config integer NOT NULL,
    url text NOT NULL,
    alt character varying(255) DEFAULT 'Imagen del hero'::character varying NOT NULL,
    orden integer DEFAULT 1 NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    fecha_creacion timestamp with time zone NOT NULL
);


ALTER TABLE public.hero_images OWNER TO appuser;

--
-- Name: hero_images_id_imagen_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public.hero_images_id_imagen_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hero_images_id_imagen_seq OWNER TO appuser;

--
-- Name: hero_images_id_imagen_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public.hero_images_id_imagen_seq OWNED BY public.hero_images.id_imagen;


--
-- Name: momentos_destacados_config; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.momentos_destacados_config (
    id_config integer NOT NULL,
    titulo character varying(100) DEFAULT 'Momentos Destacados'::character varying NOT NULL,
    sub_titulo character varying(200) DEFAULT 'Los mejores momentos del voleibol jujeño'::character varying NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    fecha_creacion timestamp with time zone NOT NULL,
    fecha_actualizacion timestamp with time zone NOT NULL
);


ALTER TABLE public.momentos_destacados_config OWNER TO appuser;

--
-- Name: momentos_destacados_config_id_config_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public.momentos_destacados_config_id_config_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.momentos_destacados_config_id_config_seq OWNER TO appuser;

--
-- Name: momentos_destacados_config_id_config_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public.momentos_destacados_config_id_config_seq OWNED BY public.momentos_destacados_config.id_config;


--
-- Name: momentos_destacados_images; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.momentos_destacados_images (
    id_imagen integer NOT NULL,
    id_config integer NOT NULL,
    url text NOT NULL,
    titulo character varying(100) NOT NULL,
    descripcion text,
    alt character varying(150) NOT NULL,
    orden integer DEFAULT 1 NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    fecha_creacion timestamp with time zone NOT NULL
);


ALTER TABLE public.momentos_destacados_images OWNER TO appuser;

--
-- Name: momentos_destacados_images_id_imagen_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public.momentos_destacados_images_id_imagen_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.momentos_destacados_images_id_imagen_seq OWNER TO appuser;

--
-- Name: momentos_destacados_images_id_imagen_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public.momentos_destacados_images_id_imagen_seq OWNED BY public.momentos_destacados_images.id_imagen;


--
-- Name: noticia_vistas; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.noticia_vistas (
    id integer NOT NULL,
    "noticiaId" integer NOT NULL,
    ip character varying(45) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.noticia_vistas OWNER TO appuser;

--
-- Name: noticia_vistas_id_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public.noticia_vistas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.noticia_vistas_id_seq OWNER TO appuser;

--
-- Name: noticia_vistas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public.noticia_vistas_id_seq OWNED BY public.noticia_vistas.id;


--
-- Name: noticias; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.noticias (
    "idNoticia" integer NOT NULL,
    titulo character varying(300) NOT NULL,
    resumen character varying(500),
    bloques json DEFAULT '[]'::json NOT NULL,
    "imagenPrincipal" character varying(1000),
    "imagenPrincipalAlt" character varying(200),
    estado character varying(20) DEFAULT 'BORRADOR'::character varying NOT NULL,
    "fechaPublicacion" timestamp with time zone,
    "fechaProgramada" timestamp with time zone,
    categoria character varying(100) DEFAULT 'GENERAL'::character varying,
    etiquetas character varying(500),
    destacado boolean DEFAULT false NOT NULL,
    vistas integer DEFAULT 0 NOT NULL,
    "autorId" integer NOT NULL,
    "editorId" integer,
    contenido text,
    slug character varying(350),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.noticias OWNER TO appuser;

--
-- Name: COLUMN noticias.bloques; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.noticias.bloques IS 'Array de bloques de contenido: texto, imagen, galería, etc.';


--
-- Name: COLUMN noticias."imagenPrincipal"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.noticias."imagenPrincipal" IS 'URL de imagen principal para vista previa y redes sociales';


--
-- Name: COLUMN noticias."imagenPrincipalAlt"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.noticias."imagenPrincipalAlt" IS 'Texto alternativo para la imagen principal';


--
-- Name: COLUMN noticias.estado; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.noticias.estado IS 'Estado de la noticia: ACTIVO (publicada), INACTIVO (despublicada), BORRADOR';


--
-- Name: COLUMN noticias."fechaPublicacion"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.noticias."fechaPublicacion" IS 'Fecha en que se publicó la noticia (null si es borrador)';


--
-- Name: COLUMN noticias."fechaProgramada"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.noticias."fechaProgramada" IS 'Fecha programada para publicación automática';


--
-- Name: COLUMN noticias.etiquetas; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.noticias.etiquetas IS 'Etiquetas separadas por comas para SEO y búsqueda';


--
-- Name: COLUMN noticias.destacado; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.noticias.destacado IS 'Si la noticia aparece destacada en la página principal';


--
-- Name: COLUMN noticias.vistas; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.noticias.vistas IS 'Contador de vistas de la noticia';


--
-- Name: COLUMN noticias."autorId"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.noticias."autorId" IS 'ID del usuario que creó la noticia';


--
-- Name: COLUMN noticias."editorId"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.noticias."editorId" IS 'ID del último usuario que editó la noticia';


--
-- Name: COLUMN noticias.slug; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.noticias.slug IS 'Slug generado a partir del título para URLs amigables';


--
-- Name: noticias_idNoticia_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public."noticias_idNoticia_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."noticias_idNoticia_seq" OWNER TO appuser;

--
-- Name: noticias_idNoticia_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public."noticias_idNoticia_seq" OWNED BY public.noticias."idNoticia";


--
-- Name: pagos; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.pagos (
    "idPago" integer NOT NULL,
    "idCobro" integer NOT NULL,
    monto numeric(10,2) NOT NULL,
    estado character varying(50) DEFAULT 'Pendiente'::character varying NOT NULL,
    "paymentId" character varying(255),
    "preferenceId" character varying(255),
    "metodoPago" character varying(100) DEFAULT 'MercadoPago'::character varying NOT NULL,
    "datosExtra" json,
    "fechaPago" timestamp with time zone,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.pagos OWNER TO appuser;

--
-- Name: COLUMN pagos."idCobro"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pagos."idCobro" IS 'ID del cobro asociado a este pago';


--
-- Name: COLUMN pagos.monto; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pagos.monto IS 'Monto del pago';


--
-- Name: COLUMN pagos.estado; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pagos.estado IS 'Estado del pago: Pendiente, Pagado, Rechazado, Anulado, etc.';


--
-- Name: COLUMN pagos."paymentId"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pagos."paymentId" IS 'ID del pago en el sistema externo (MercadoPago, etc.)';


--
-- Name: COLUMN pagos."preferenceId"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pagos."preferenceId" IS 'ID de la preferencia de pago en MercadoPago';


--
-- Name: COLUMN pagos."metodoPago"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pagos."metodoPago" IS 'Método de pago utilizado';


--
-- Name: COLUMN pagos."datosExtra"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pagos."datosExtra" IS 'Datos adicionales del pago en formato JSON';


--
-- Name: COLUMN pagos."fechaPago"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pagos."fechaPago" IS 'Fecha en que se registró el pago exitoso';


--
-- Name: pagos_idPago_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public."pagos_idPago_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."pagos_idPago_seq" OWNER TO appuser;

--
-- Name: pagos_idPago_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public."pagos_idPago_seq" OWNED BY public.pagos."idPago";


--
-- Name: pases; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.pases (
    "idPase" integer NOT NULL,
    "idPersona" integer NOT NULL,
    "clubProveniente" character varying(255),
    "idClubProveniente" integer,
    "clubDestino" character varying(255) NOT NULL,
    "idClubDestino" integer NOT NULL,
    "fechaPase" date NOT NULL,
    habilitacion character varying(20) DEFAULT 'PENDIENTE'::character varying NOT NULL,
    motivo text,
    observaciones text,
    "datosAfiliado" jsonb,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.pases OWNER TO appuser;

--
-- Name: COLUMN pases."clubProveniente"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pases."clubProveniente" IS 'Nombre del club de origen (puede ser null si es el primer club)';


--
-- Name: COLUMN pases."idClubProveniente"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pases."idClubProveniente" IS 'ID del club de origen (puede ser null si es el primer club)';


--
-- Name: COLUMN pases."clubDestino"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pases."clubDestino" IS 'Nombre del club de destino';


--
-- Name: COLUMN pases."idClubDestino"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pases."idClubDestino" IS 'ID del club de destino';


--
-- Name: COLUMN pases."fechaPase"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pases."fechaPase" IS 'Fecha en que se realizó el pase';


--
-- Name: COLUMN pases.habilitacion; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pases.habilitacion IS 'Estado de habilitación del pase';


--
-- Name: COLUMN pases.motivo; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pases.motivo IS 'Motivo del pase (opcional)';


--
-- Name: COLUMN pases.observaciones; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pases.observaciones IS 'Observaciones adicionales sobre el pase';


--
-- Name: COLUMN pases."datosAfiliado"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.pases."datosAfiliado" IS 'Datos del afiliado al momento del pase (categoria, tipo, etc.)';


--
-- Name: pases_idPase_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public."pases_idPase_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."pases_idPase_seq" OWNER TO appuser;

--
-- Name: pases_idPase_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public."pases_idPase_seq" OWNED BY public.pases."idPase";


--
-- Name: personas; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.personas (
    "idPersona" integer NOT NULL,
    "nombreApellido" character varying(255) NOT NULL,
    dni character varying(20) NOT NULL,
    "fechaNacimiento" date NOT NULL,
    "clubActual" character varying(255),
    licencia character varying(50),
    "fechaLicencia" date,
    "fechaLicenciaBaja" date,
    "estadoLicencia" character varying(50) DEFAULT 'INACTIVO'::character varying,
    tipo character varying(255)[] DEFAULT (ARRAY[]::character varying[])::character varying(255)[],
    "paseClub" character varying(255),
    categoria character varying(100),
    "categoriaNivel" character varying(100),
    "numeroAfiliacion" integer,
    otorgado boolean DEFAULT false,
    "idClub" integer,
    foto character varying(1000),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.personas OWNER TO appuser;

--
-- Name: COLUMN personas.tipo; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.personas.tipo IS 'Roles del afiliado: Jugador, Entrenador, etc.';


--
-- Name: COLUMN personas."numeroAfiliacion"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.personas."numeroAfiliacion" IS 'Número de afiliación opcional';


--
-- Name: COLUMN personas.foto; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.personas.foto IS 'URL de la imagen de perfil almacenada en ImgBB';


--
-- Name: personas_idPersona_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public."personas_idPersona_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."personas_idPersona_seq" OWNER TO appuser;

--
-- Name: personas_idPersona_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public."personas_idPersona_seq" OWNED BY public.personas."idPersona";


--
-- Name: public_payment_links; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.public_payment_links (
    id uuid NOT NULL,
    "cobroId" integer NOT NULL,
    slug character varying(255) NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "expirationDate" timestamp with time zone,
    "accessCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.public_payment_links OWNER TO appuser;

--
-- Name: TABLE public_payment_links; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON TABLE public.public_payment_links IS 'Enlaces públicos para pagos sin autenticación';


--
-- Name: COLUMN public_payment_links.slug; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.public_payment_links.slug IS 'URL amigable basada en el concepto del cobro';


--
-- Name: COLUMN public_payment_links."isActive"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.public_payment_links."isActive" IS 'Indica si el enlace está activo y puede ser usado';


--
-- Name: COLUMN public_payment_links."expirationDate"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.public_payment_links."expirationDate" IS 'Fecha de expiración del enlace (opcional)';


--
-- Name: COLUMN public_payment_links."accessCount"; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.public_payment_links."accessCount" IS 'Contador de accesos al enlace';


--
-- Name: replica_test; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.replica_test (
    id integer NOT NULL,
    mensaje text
);


ALTER TABLE public.replica_test OWNER TO appuser;

--
-- Name: replica_test_id_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public.replica_test_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.replica_test_id_seq OWNER TO appuser;

--
-- Name: replica_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public.replica_test_id_seq OWNED BY public.replica_test.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    apellido character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    google_id character varying(255),
    linkedin_id character varying(255),
    provider_type character varying(255),
    foto_perfil character varying(255),
    email_verificado boolean DEFAULT false,
    telefono character varying(255),
    direccion jsonb,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    rol_id integer
);


ALTER TABLE public.usuarios OWNER TO appuser;

--
-- Name: COLUMN usuarios.direccion; Type: COMMENT; Schema: public; Owner: appuser
--

COMMENT ON COLUMN public.usuarios.direccion IS 'Almacena la dirección como un objeto JSON: { street, city, state, zipCode, country }';


--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuarios_id_seq OWNER TO appuser;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: work_areas; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.work_areas (
    "idArea" integer NOT NULL,
    "idConfig" integer NOT NULL,
    titulo character varying(100) NOT NULL,
    descripcion text NOT NULL,
    icono character varying(50) DEFAULT 'fas fa-question'::character varying NOT NULL,
    orden integer DEFAULT 1 NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    "fechaCreacion" timestamp with time zone NOT NULL,
    "fechaActualizacion" timestamp with time zone NOT NULL
);


ALTER TABLE public.work_areas OWNER TO appuser;

--
-- Name: work_areas_config; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.work_areas_config (
    "idConfig" integer NOT NULL,
    "tituloSeccion" character varying(100) DEFAULT 'Áreas de trabajo'::character varying NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    "fechaCreacion" timestamp with time zone NOT NULL,
    "fechaActualizacion" timestamp with time zone NOT NULL
);


ALTER TABLE public.work_areas_config OWNER TO appuser;

--
-- Name: work_areas_config_idConfig_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public."work_areas_config_idConfig_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."work_areas_config_idConfig_seq" OWNER TO appuser;

--
-- Name: work_areas_config_idConfig_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public."work_areas_config_idConfig_seq" OWNED BY public.work_areas_config."idConfig";


--
-- Name: work_areas_idArea_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public."work_areas_idArea_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."work_areas_idArea_seq" OWNER TO appuser;

--
-- Name: work_areas_idArea_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public."work_areas_idArea_seq" OWNED BY public.work_areas."idArea";


--
-- Name: Rols id; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public."Rols" ALTER COLUMN id SET DEFAULT nextval('public."Rols_id_seq"'::regclass);


--
-- Name: categorias idCategoria; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.categorias ALTER COLUMN "idCategoria" SET DEFAULT nextval('public."categorias_idCategoria_seq"'::regclass);


--
-- Name: clubs idClub; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.clubs ALTER COLUMN "idClub" SET DEFAULT nextval('public."clubs_idClub_seq"'::regclass);


--
-- Name: cobros idCobro; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.cobros ALTER COLUMN "idCobro" SET DEFAULT nextval('public."cobros_idCobro_seq"'::regclass);


--
-- Name: contactos idContacto; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.contactos ALTER COLUMN "idContacto" SET DEFAULT nextval('public."contactos_idContacto_seq"'::regclass);


--
-- Name: credenciales idCredencial; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.credenciales ALTER COLUMN "idCredencial" SET DEFAULT nextval('public."credenciales_idCredencial_seq"'::regclass);


--
-- Name: equipos idEquipo; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.equipos ALTER COLUMN "idEquipo" SET DEFAULT nextval('public."equipos_idEquipo_seq"'::regclass);


--
-- Name: hero_config id_config; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.hero_config ALTER COLUMN id_config SET DEFAULT nextval('public.hero_config_id_config_seq'::regclass);


--
-- Name: hero_images id_imagen; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.hero_images ALTER COLUMN id_imagen SET DEFAULT nextval('public.hero_images_id_imagen_seq'::regclass);


--
-- Name: momentos_destacados_config id_config; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.momentos_destacados_config ALTER COLUMN id_config SET DEFAULT nextval('public.momentos_destacados_config_id_config_seq'::regclass);


--
-- Name: momentos_destacados_images id_imagen; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.momentos_destacados_images ALTER COLUMN id_imagen SET DEFAULT nextval('public.momentos_destacados_images_id_imagen_seq'::regclass);


--
-- Name: noticia_vistas id; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.noticia_vistas ALTER COLUMN id SET DEFAULT nextval('public.noticia_vistas_id_seq'::regclass);


--
-- Name: noticias idNoticia; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.noticias ALTER COLUMN "idNoticia" SET DEFAULT nextval('public."noticias_idNoticia_seq"'::regclass);


--
-- Name: pagos idPago; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.pagos ALTER COLUMN "idPago" SET DEFAULT nextval('public."pagos_idPago_seq"'::regclass);


--
-- Name: pases idPase; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.pases ALTER COLUMN "idPase" SET DEFAULT nextval('public."pases_idPase_seq"'::regclass);


--
-- Name: personas idPersona; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.personas ALTER COLUMN "idPersona" SET DEFAULT nextval('public."personas_idPersona_seq"'::regclass);


--
-- Name: replica_test id; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.replica_test ALTER COLUMN id SET DEFAULT nextval('public.replica_test_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Name: work_areas idArea; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.work_areas ALTER COLUMN "idArea" SET DEFAULT nextval('public."work_areas_idArea_seq"'::regclass);


--
-- Name: work_areas_config idConfig; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.work_areas_config ALTER COLUMN "idConfig" SET DEFAULT nextval('public."work_areas_config_idConfig_seq"'::regclass);


--
-- Data for Name: Rols; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public."Rols" (id, nombre, descripcion, "createdAt", "updatedAt") FROM stdin;
1	admin	Administrador del sistema	2025-11-06 20:17:36.03+00	2025-11-06 20:17:36.03+00
2	usuario	Usuario regular	2025-11-06 20:17:36.03+00	2025-11-06 20:17:36.03+00
3	usuario_social	Usuario de redes sociales	2025-11-06 20:17:36.03+00	2025-11-06 20:17:36.03+00
\.


--
-- Data for Name: categorias; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.categorias ("idCategoria", nombre, tipo, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: clubs; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.clubs ("idClub", nombre, direccion, telefono, email, cuit, "fechaAfiliacion", "estadoAfiliacion", logo, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: cobros; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.cobros ("idCobro", concepto, monto, "fechaCobro", "fechaVencimiento", estado, "comprobantePago", observaciones, "preferenciaMP", "fechaPago", "idClub", "idEquipo", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: contactos; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.contactos ("idContacto", direccion, telefono, email, horarios, "mapaEmbed", facebook, instagram, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: credenciales; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.credenciales ("idCredencial", identificador, "fechaAlta", "fechaVencimiento", estado, "motivoSuspension", "idPersona", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: equipos; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.equipos ("idEquipo", nombre, "idClub", "idCategoria", "nombreDelegado", "telefonoDelegado", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: hero_config; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.hero_config (id_config, eslogan, sub_texto, activo, fecha_creacion, fecha_actualizacion) FROM stdin;
1	Pasión por el Voleibol	Promoviendo el voleibol en la provincia de Jujuy desde sus bases	t	2025-11-06 21:04:33.744+00	2025-11-06 21:04:33.744+00
\.


--
-- Data for Name: hero_images; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.hero_images (id_imagen, id_config, url, alt, orden, activo, fecha_creacion) FROM stdin;
1	1	assets/images/volleyball-hero.png	Voleibol en acción	1	t	2025-11-06 21:04:33.873+00
\.


--
-- Data for Name: momentos_destacados_config; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.momentos_destacados_config (id_config, titulo, sub_titulo, activo, fecha_creacion, fecha_actualizacion) FROM stdin;
1	Momentos Destacados	Los mejores momentos del voleibol jujeño	t	2025-11-06 21:04:33.876+00	2025-11-06 21:04:33.876+00
\.


--
-- Data for Name: momentos_destacados_images; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.momentos_destacados_images (id_imagen, id_config, url, titulo, descripcion, alt, orden, activo, fecha_creacion) FROM stdin;
\.


--
-- Data for Name: noticia_vistas; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.noticia_vistas (id, "noticiaId", ip, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: noticias; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.noticias ("idNoticia", titulo, resumen, bloques, "imagenPrincipal", "imagenPrincipalAlt", estado, "fechaPublicacion", "fechaProgramada", categoria, etiquetas, destacado, vistas, "autorId", "editorId", contenido, slug, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: pagos; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.pagos ("idPago", "idCobro", monto, estado, "paymentId", "preferenceId", "metodoPago", "datosExtra", "fechaPago", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: pases; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.pases ("idPase", "idPersona", "clubProveniente", "idClubProveniente", "clubDestino", "idClubDestino", "fechaPase", habilitacion, motivo, observaciones, "datosAfiliado", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: personas; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.personas ("idPersona", "nombreApellido", dni, "fechaNacimiento", "clubActual", licencia, "fechaLicencia", "fechaLicenciaBaja", "estadoLicencia", tipo, "paseClub", categoria, "categoriaNivel", "numeroAfiliacion", otorgado, "idClub", foto, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: public_payment_links; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.public_payment_links (id, "cobroId", slug, "isActive", "expirationDate", "accessCount", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: replica_test; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.replica_test (id, mensaje) FROM stdin;
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.usuarios (id, nombre, apellido, email, password, google_id, linkedin_id, provider_type, foto_perfil, email_verificado, telefono, direccion, created_at, updated_at, rol_id) FROM stdin;
1	Admin	Sistema	admin@admin.com	$2b$10$UEF8vMrhpSMP/7g4dQdVSuGey90krWI8hGdCjIz1iYC2PD3WT.q26	\N	\N	\N	\N	t	\N	\N	2025-11-06 20:17:36.053+00	2025-11-06 20:17:36.053+00	1
2	Usuario	Regular	usuario@sistema.com	$2b$10$/VigEu2pU8uXWYZjQSa8iufQ6S7X33Xb3TtL1jjleUIWtiyCBvkqm	\N	\N	\N	\N	t	\N	\N	2025-11-06 20:17:36.156+00	2025-11-06 20:17:36.156+00	2
\.


--
-- Data for Name: work_areas; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.work_areas ("idArea", "idConfig", titulo, descripcion, icono, orden, activo, "fechaCreacion", "fechaActualizacion") FROM stdin;
1	1	Torneos Provinciales	Organizamos torneos en todas las categorías, promoviendo la competencia a nivel provincial y regional.	fas fa-trophy	1	t	2025-11-06 21:04:33.88+00	2025-11-06 21:04:33.88+00
2	1	Selecciones Provinciales	Formamos y preparamos las selecciones de Jujuy para representar a nuestra provincia en torneos nacionales.	fas fa-users	2	t	2025-11-06 21:04:33.88+00	2025-11-06 21:04:33.88+00
3	1	Capacitación Deportiva	Ofrecemos cursos para jugadores, entrenadores y árbitros para mantener el alto nivel del voley jujeño.	fas fa-graduation-cap	3	t	2025-11-06 21:04:33.88+00	2025-11-06 21:04:33.88+00
\.


--
-- Data for Name: work_areas_config; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.work_areas_config ("idConfig", "tituloSeccion", activo, "fechaCreacion", "fechaActualizacion") FROM stdin;
1	Áreas de trabajo	t	2025-11-06 21:04:33.809+00	2025-11-06 21:04:33.809+00
\.


--
-- Name: Rols_id_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public."Rols_id_seq"', 3, true);


--
-- Name: categorias_idCategoria_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public."categorias_idCategoria_seq"', 1, false);


--
-- Name: clubs_idClub_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public."clubs_idClub_seq"', 1, false);


--
-- Name: cobros_idCobro_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public."cobros_idCobro_seq"', 1, false);


--
-- Name: contactos_idContacto_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public."contactos_idContacto_seq"', 1, false);


--
-- Name: credenciales_idCredencial_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public."credenciales_idCredencial_seq"', 1, false);


--
-- Name: equipos_idEquipo_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public."equipos_idEquipo_seq"', 1, false);


--
-- Name: hero_config_id_config_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public.hero_config_id_config_seq', 1, true);


--
-- Name: hero_images_id_imagen_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public.hero_images_id_imagen_seq', 1, true);


--
-- Name: momentos_destacados_config_id_config_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public.momentos_destacados_config_id_config_seq', 1, true);


--
-- Name: momentos_destacados_images_id_imagen_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public.momentos_destacados_images_id_imagen_seq', 1, false);


--
-- Name: noticia_vistas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public.noticia_vistas_id_seq', 1, false);


--
-- Name: noticias_idNoticia_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public."noticias_idNoticia_seq"', 1, false);


--
-- Name: pagos_idPago_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public."pagos_idPago_seq"', 1, false);


--
-- Name: pases_idPase_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public."pases_idPase_seq"', 1, false);


--
-- Name: personas_idPersona_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public."personas_idPersona_seq"', 1, false);


--
-- Name: replica_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public.replica_test_id_seq', 1, false);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 2, true);


--
-- Name: work_areas_config_idConfig_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public."work_areas_config_idConfig_seq"', 1, true);


--
-- Name: work_areas_idArea_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public."work_areas_idArea_seq"', 3, true);


--
-- Name: Rols Rols_nombre_key; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public."Rols"
    ADD CONSTRAINT "Rols_nombre_key" UNIQUE (nombre);


--
-- Name: Rols Rols_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public."Rols"
    ADD CONSTRAINT "Rols_pkey" PRIMARY KEY (id);


--
-- Name: categorias categorias_nombre_key; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_nombre_key UNIQUE (nombre);


--
-- Name: categorias categorias_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_pkey PRIMARY KEY ("idCategoria");


--
-- Name: clubs clubs_cuit_key; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.clubs
    ADD CONSTRAINT clubs_cuit_key UNIQUE (cuit);


--
-- Name: clubs clubs_email_key; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.clubs
    ADD CONSTRAINT clubs_email_key UNIQUE (email);


--
-- Name: clubs clubs_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.clubs
    ADD CONSTRAINT clubs_pkey PRIMARY KEY ("idClub");


--
-- Name: cobros cobros_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.cobros
    ADD CONSTRAINT cobros_pkey PRIMARY KEY ("idCobro");


--
-- Name: contactos contactos_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.contactos
    ADD CONSTRAINT contactos_pkey PRIMARY KEY ("idContacto");


--
-- Name: credenciales credenciales_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.credenciales
    ADD CONSTRAINT credenciales_pkey PRIMARY KEY ("idCredencial");


--
-- Name: equipos equipos_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.equipos
    ADD CONSTRAINT equipos_pkey PRIMARY KEY ("idEquipo");


--
-- Name: hero_config hero_config_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.hero_config
    ADD CONSTRAINT hero_config_pkey PRIMARY KEY (id_config);


--
-- Name: hero_images hero_images_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.hero_images
    ADD CONSTRAINT hero_images_pkey PRIMARY KEY (id_imagen);


--
-- Name: momentos_destacados_config momentos_destacados_config_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.momentos_destacados_config
    ADD CONSTRAINT momentos_destacados_config_pkey PRIMARY KEY (id_config);


--
-- Name: momentos_destacados_images momentos_destacados_images_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.momentos_destacados_images
    ADD CONSTRAINT momentos_destacados_images_pkey PRIMARY KEY (id_imagen);


--
-- Name: noticia_vistas noticia_vistas_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.noticia_vistas
    ADD CONSTRAINT noticia_vistas_pkey PRIMARY KEY (id);


--
-- Name: noticias noticias_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.noticias
    ADD CONSTRAINT noticias_pkey PRIMARY KEY ("idNoticia");


--
-- Name: pagos pagos_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.pagos
    ADD CONSTRAINT pagos_pkey PRIMARY KEY ("idPago");


--
-- Name: pases pases_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.pases
    ADD CONSTRAINT pases_pkey PRIMARY KEY ("idPase");


--
-- Name: personas personas_dni_key; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.personas
    ADD CONSTRAINT personas_dni_key UNIQUE (dni);


--
-- Name: personas personas_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.personas
    ADD CONSTRAINT personas_pkey PRIMARY KEY ("idPersona");


--
-- Name: public_payment_links public_payment_links_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.public_payment_links
    ADD CONSTRAINT public_payment_links_pkey PRIMARY KEY (id);


--
-- Name: replica_test replica_test_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.replica_test
    ADD CONSTRAINT replica_test_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_email_key; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_email_key UNIQUE (email);


--
-- Name: usuarios usuarios_google_id_key; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_google_id_key UNIQUE (google_id);


--
-- Name: usuarios usuarios_linkedin_id_key; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_linkedin_id_key UNIQUE (linkedin_id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: work_areas_config work_areas_config_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.work_areas_config
    ADD CONSTRAINT work_areas_config_pkey PRIMARY KEY ("idConfig");


--
-- Name: work_areas work_areas_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.work_areas
    ADD CONSTRAINT work_areas_pkey PRIMARY KEY ("idArea");


--
-- Name: credenciales_identificador_unique; Type: INDEX; Schema: public; Owner: appuser
--

CREATE UNIQUE INDEX credenciales_identificador_unique ON public.credenciales USING btree (identificador);


--
-- Name: momentos_destacados_images_activo; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX momentos_destacados_images_activo ON public.momentos_destacados_images USING btree (activo);


--
-- Name: momentos_destacados_images_id_config_orden; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX momentos_destacados_images_id_config_orden ON public.momentos_destacados_images USING btree (id_config, orden);


--
-- Name: pases_fecha_pase; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX pases_fecha_pase ON public.pases USING btree ("fechaPase");


--
-- Name: pases_id_club_destino; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX pases_id_club_destino ON public.pases USING btree ("idClubDestino");


--
-- Name: pases_id_club_proveniente; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX pases_id_club_proveniente ON public.pases USING btree ("idClubProveniente");


--
-- Name: pases_id_persona; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX pases_id_persona ON public.pases USING btree ("idPersona");


--
-- Name: public_payment_links_cobro_id; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX public_payment_links_cobro_id ON public.public_payment_links USING btree ("cobroId");


--
-- Name: public_payment_links_created_at; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX public_payment_links_created_at ON public.public_payment_links USING btree ("createdAt");


--
-- Name: public_payment_links_is_active; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX public_payment_links_is_active ON public.public_payment_links USING btree ("isActive");


--
-- Name: public_payment_links_slug; Type: INDEX; Schema: public; Owner: appuser
--

CREATE UNIQUE INDEX public_payment_links_slug ON public.public_payment_links USING btree (slug);


--
-- Name: usuarios_email; Type: INDEX; Schema: public; Owner: appuser
--

CREATE UNIQUE INDEX usuarios_email ON public.usuarios USING btree (email);


--
-- Name: cobros cobros_idClub_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.cobros
    ADD CONSTRAINT "cobros_idClub_fkey" FOREIGN KEY ("idClub") REFERENCES public.clubs("idClub") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cobros cobros_idEquipo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.cobros
    ADD CONSTRAINT "cobros_idEquipo_fkey" FOREIGN KEY ("idEquipo") REFERENCES public.equipos("idEquipo") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: credenciales credenciales_idPersona_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.credenciales
    ADD CONSTRAINT "credenciales_idPersona_fkey" FOREIGN KEY ("idPersona") REFERENCES public.personas("idPersona") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: equipos equipos_idCategoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.equipos
    ADD CONSTRAINT "equipos_idCategoria_fkey" FOREIGN KEY ("idCategoria") REFERENCES public.categorias("idCategoria") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: equipos equipos_idClub_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.equipos
    ADD CONSTRAINT "equipos_idClub_fkey" FOREIGN KEY ("idClub") REFERENCES public.clubs("idClub") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hero_images hero_images_id_config_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.hero_images
    ADD CONSTRAINT hero_images_id_config_fkey FOREIGN KEY (id_config) REFERENCES public.hero_config(id_config) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: momentos_destacados_images momentos_destacados_images_id_config_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.momentos_destacados_images
    ADD CONSTRAINT momentos_destacados_images_id_config_fkey FOREIGN KEY (id_config) REFERENCES public.momentos_destacados_config(id_config) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: noticia_vistas noticia_vistas_noticiaId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.noticia_vistas
    ADD CONSTRAINT "noticia_vistas_noticiaId_fkey" FOREIGN KEY ("noticiaId") REFERENCES public.noticias("idNoticia") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: noticias noticias_autorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.noticias
    ADD CONSTRAINT "noticias_autorId_fkey" FOREIGN KEY ("autorId") REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: noticias noticias_editorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.noticias
    ADD CONSTRAINT "noticias_editorId_fkey" FOREIGN KEY ("editorId") REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: pagos pagos_idCobro_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.pagos
    ADD CONSTRAINT "pagos_idCobro_fkey" FOREIGN KEY ("idCobro") REFERENCES public.cobros("idCobro") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pases pases_idClubDestino_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.pases
    ADD CONSTRAINT "pases_idClubDestino_fkey" FOREIGN KEY ("idClubDestino") REFERENCES public.clubs("idClub") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pases pases_idClubProveniente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.pases
    ADD CONSTRAINT "pases_idClubProveniente_fkey" FOREIGN KEY ("idClubProveniente") REFERENCES public.clubs("idClub") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: pases pases_idPersona_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.pases
    ADD CONSTRAINT "pases_idPersona_fkey" FOREIGN KEY ("idPersona") REFERENCES public.personas("idPersona") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: personas personas_idClub_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.personas
    ADD CONSTRAINT "personas_idClub_fkey" FOREIGN KEY ("idClub") REFERENCES public.clubs("idClub") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: public_payment_links public_payment_links_cobroId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.public_payment_links
    ADD CONSTRAINT "public_payment_links_cobroId_fkey" FOREIGN KEY ("cobroId") REFERENCES public.cobros("idCobro") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usuarios usuarios_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public."Rols"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: work_areas work_areas_idConfig_fkey; Type: FK CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.work_areas
    ADD CONSTRAINT "work_areas_idConfig_fkey" FOREIGN KEY ("idConfig") REFERENCES public.work_areas_config("idConfig") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict SOimFHM7IDLgnVvVji51OQbZcbXbDi6U9QBUYCTKAbzVSPAV0fX9n5ujcKAARyl

