--
-- PostgreSQL database dump
--

\restrict 71lr81ej5A35X6oXBBG8a4LdTP2ZMAT0h04RWaHkyW35FBCQXxRaJlRLsi68h5K

-- Dumped from database version 16.6
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: appuser
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO appuser;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: replica_test; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.replica_test (
    id integer NOT NULL,
    mensaje text
);


ALTER TABLE public.replica_test OWNER TO appuser;

--
-- Name: replica_test_id_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public.replica_test_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.replica_test_id_seq OWNER TO appuser;

--
-- Name: replica_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public.replica_test_id_seq OWNED BY public.replica_test.id;


--
-- Name: replica_test id; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.replica_test ALTER COLUMN id SET DEFAULT nextval('public.replica_test_id_seq'::regclass);


--
-- Data for Name: replica_test; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.replica_test (id, mensaje) FROM stdin;
\.


--
-- Name: replica_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public.replica_test_id_seq', 1, false);


--
-- Name: replica_test replica_test_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.replica_test
    ADD CONSTRAINT replica_test_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict 71lr81ej5A35X6oXBBG8a4LdTP2ZMAT0h04RWaHkyW35FBCQXxRaJlRLsi68h5K

